﻿class Program
{
    static string comprobador = "0";
    static object[,] matrizAlumno = new object[11,10]; 
    static double[] promedio = new double[matrizAlumno.GetLength(1)];
    public static void Menu()
    {
        while (true)
        {
            Console.WriteLine("Menu, seleccione una opción:");
            Console.WriteLine("1. Mostrar alumnos y  aprobadas notas");
            Console.WriteLine("2. Mostrar alumnos y nota reprobada");
            Console.WriteLine("3. Mostrar alumnos y promedio");
            Console.WriteLine("4. Salir");
            Console.WriteLine("Ingrese una opción: ");
            comprobador = Console.ReadLine()!;
            if(int.TryParse(comprobador, out int opcion))
            {
                if (opcion < 1 || opcion > 3)
                {
                    Console.WriteLine("Opción no válida. Intente de nuevo.");
                    continue;
                }
                 else   
                {
                    switch (opcion)
                    {
                    case 1:
                        MostrarAlumnosAprobado();
                        break;
                    case 2:
                        MostrarAlumnosReprobado();
                        break;
                    case 3: 
                        PromedioNota();
                        break;
                    default:
                        break;
                    }
                    if (opcion == 4)
                    {
                        Console.WriteLine("Saliendo del programa...");
                        break;
                    }
                }
            }	
        }
    }
    public static void PromedioNota()
    {
        for (int i = 1; i < matrizAlumno.GetLength(0); i++)
        {
            for (int j = 0; j < matrizAlumno.GetLength(1); j++)
            {
                if (matrizAlumno[i,j] != null)
                {
                    promedio[j] += Convert.ToDouble(matrizAlumno[i,j]);
                }
            }
        }
        for (int j = 0; j < matrizAlumno.GetLength(1); j++)
        {
            promedio[j] /= matrizAlumno.GetLength(1);
            Console.WriteLine($"Alumnos y sus notas:");
            Console.WriteLine($"Alumno {j + 1}: {matrizAlumno[0,j]}");
            Console.WriteLine($"El promedio de la nota {j+1} es: {promedio[j]}");
        }
    }
    public static void MostrarAlumnosAprobado()
    {
        Console.WriteLine("Alumnos y sus notas:");
        for(int i =0; i< matrizAlumno.GetLength(1); i++)
        {
            Console.WriteLine($"Alumno {i + 1}: {matrizAlumno[0,i]}");
            for (int j = 0; j < matrizAlumno.GetLength(1); j++)
            {
                if (matrizAlumno[0,j] != null && Convert.ToDouble(matrizAlumno[i+1,j])> 64)
                {
                    Console.WriteLine($"Nota Aprobada: {matrizAlumno[i+1,j]} ");
                }
            }
        }
    }
    public static void MostrarAlumnosReprobado()
    {
        Console.WriteLine("Alumnos y sus notas:");
        for(int i =0; i< matrizAlumno.GetLength(1); i++)
        {
            Console.WriteLine($"Alumno {i + 1}: {matrizAlumno[0,i]}");
            for (int j = 0; j < matrizAlumno.GetLength(1); j++)
            {
                if (matrizAlumno[0,j] != null && Convert.ToDouble(matrizAlumno[i+1,j]) < 65)
                {
                    Console.WriteLine($"Nota Aprobada {j+1}: {matrizAlumno[i+1,j]} ");
                }
            }
        }
    }
    static void Main(string[] args)
    {

        for (int i = 0; i < matrizAlumno.GetLength(0); i++)
        {
            for (int j = 0; j < matrizAlumno.GetLength(1); j++)
            {
                if (i == 0)
                {
                    while(true)
                    {
                        Console.WriteLine($"Ingrese el nombre del estudiante {j + 1} ");
                        matrizAlumno[i,j] = Console.ReadLine()!;
                        if (matrizAlumno[i,j] != null)
                        {
                            break;
                        }
                        else
                        {
                            Console.WriteLine("El nombre no puede estar vacío. Intente de nuevo.");
                        }
                    }
                }
                else if(i > 0)
                {
                    while(true)
                    {
                        Console.WriteLine($"Ingrese la nota {j+1} del estudiante {i}, {matrizAlumno[0,i-1]}, la nota debe ser un número entre 0 y 100:");
                        comprobador = Console.ReadLine()!;
                        if (double.TryParse(comprobador, out double tempNota) && tempNota >= 0 && tempNota <= 100)
                        {
                            matrizAlumno[i, j] = tempNota;
                            break;
                        }
                        else
                        {
                            Console.WriteLine("La nota no es válida. Intente de nuevo.");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Si llego aqui no se porque");
                }
            }
        }
        Console.Clear();     
        Menu();
    }
}