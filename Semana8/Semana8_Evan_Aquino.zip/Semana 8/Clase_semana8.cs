﻿using System.Data;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
class clase_semana8_actvidad_1
{
    static void Main(String[] args)
    {
        int numeroEntero=-1;
        while(numeroEntero < 0)
        {
            Console.WriteLine("Ingresa el numero al cual deseas saber su factorial");
            numeroEntero = Convert.ToInt32(Console.ReadLine());
            int i = 1;
             if(i<=0)
            {
                Console.WriteLine("La factorial de un numero negativa es indifinida es 0 ingreses otro numero.");
            }
            if(numeroEntero>-1)
            {
                int factorial = CalcularFactorial(numeroEntero);
                Console.WriteLine("El numero factorial de " + numeroEntero + " es: " + factorial);
            }
            i=i-1;
        }
    }
    public static int CalcularFactorial(int numero)
    {
        if(numero == 0)
        {
            return 1;
        }
        else
        {
            int factorial=1;
            for(int i=1; i<= numero; i++)
            {
                factorial *= i;
            }
            return factorial;
        }

    }
}
