﻿namespace patata
{
    public class Noje
    {
        static void Main(string[] args)
        {
            string? escoger = "Noje";
            double centigrados = 0, fahernheit = 0;
            Console.WriteLine("Bienvenido a la calculadora de temperatura");
            Console.WriteLine("Por favor, ingrese que desea convertir, De fahernheit a centigrados, De centigrados a fahernheit");
            escoger = Console.ReadLine();
            escoger = escoger.ToLower();
            if (escoger.Contains("de centigrados a fahernheit") || escoger.Contains("centigrados a fahernheit") || escoger.Contains("c a f"))
            {
                Console.WriteLine("Ingrese los grados centigrados: ");
                centigrados = Convert.ToDouble(Console.ReadLine());
                fahernheit = (centigrados * 9 / 5) + 32;
                Console.WriteLine("Los grados fahernheit son: " + fahernheit);
            }
            else if (escoger.Contains("de fahernheit a centigrados") || escoger.Contains("fahernheit a centigrados") || escoger.Contains("f a c")) 
            {
                Console.WriteLine("Ingrese los grados fahernheit: "); 
                fahernheit = Convert.ToDouble(Console.ReadLine());
                centigrados = (fahernheit - 32) * 5 / 9;
                Console.WriteLine("Los grados centigrados son: " + centigrados);
            }
            else
            {
                Console.WriteLine("Opcion no valida, revisar si escribio bien");
            }
        }
    }
}	